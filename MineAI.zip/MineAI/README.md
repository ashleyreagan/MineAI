# MineAI — Historic Mine Map AI Pipeline

AI + OCR + Georeferencing for underground mine maps. Modules include ingestion, AI‑assisted georeferencing, OCR (Tesseract/TrOCR), YOLO portal detection, PDAL/LiDAR hooks, and a Streamlit GUI.

## Quickstart
```bash
conda env create -f environment.yml
conda activate mineai
python run_pipeline.py
# or
streamlit run src/gui/app_streamlit.py
```